document.getElementById('sign-up-button').addEventListener('click', function() {
	document.getElementById('login-page').style.display = 'none';
	document.getElementById('sign-up-page').style.display = 'block';
});

document.getElementById('login-button').addEventListener('click', function() {
	document.getElementById('sign-up-page').style.display = 'none';
	document.getElementById('login-page').style.display = 'block';
});