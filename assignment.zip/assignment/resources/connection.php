<?php
// Connect to database
$host = 'localhost';
$user = 'username';
$password = 'password';
$dbname = 'database';
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
	die('Connection failed: ' . $conn->connect_error);
}

// Handle sign up form submission
if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])) {
	// Get form data
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

	// Insert user into database
	$sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
	$stmt = $conn->prepare($sql);
	$stmt->bind_param('sss', $username, $email, $password);
	$stmt->execute();

	// Close statement
	$stmt->close();
}

// Handle login form submission
if (isset($_POST['username']) && isset($_POST['password'])) {
	// Get form data
	$username = $_POST['username'];
	$password = $_POST['password'];

	// Check if user exists in database
	$sql = "SELECT id, password FROM users WHERE username = ?";
	$stmt = $conn->prepare($sql);
	$stmt->bind_param('s', $username);
	$stmt->execute();
	$result = $stmt->get_result();
	$row = $result->fetch_assoc();

	// Check if user exists and password is correct
	if ($row && password_verify($password, $row['password'])) {
		// Set session variable
		session_start();
		$_SESSION['user_id'] = $row['id'];

		// Redirect to home page
		header('Location: home.php');
		exit;
	}

	// Close statement
	$stmt->close();
}

// Close connection
$conn->close();
?>