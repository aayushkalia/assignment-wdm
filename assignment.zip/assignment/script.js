document.getElementById('sign-up-button').addEventListener('click', function() {
	document.getElementById('login-page').style.display = 'none';
	document.getElementById('sign-up-page').style.display = 'block';
});

document.getElementById('login-button').addEventListener('click', function() {
	document.getElementById('sign-up-page').style.display = 'none';
	document.getElementById('login-page').style.display = 'block';
});

document.getElementById('sign-up-form').addEventListener('submit', function(event) {
	event.preventDefault();

	// Get form data
	var formData = new FormData(document.getElementById('sign-up-form'));

	// Send form data to server
	var xhr = new XMLHttpRequest();
	xhr.open('POST', 'resources/connection.php');
	xhr.send(formData);

	// Clear form
	document.getElementById('sign-up-form').reset();
});

document.getElementById('login-form').addEventListener('submit', function(event) {
	event.preventDefault();

	// Get form data
	var formData = new FormData(document.getElementById('login-form'));

	// Send form data to server
	var xhr = new XMLHttpRequest();
	xhr.open('POST', 'resources/connection.php');
	xhr.send(formData);

	// Clear form
	document.getElementById('login-form').reset();
});